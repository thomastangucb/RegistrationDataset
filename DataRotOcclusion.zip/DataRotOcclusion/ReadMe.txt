This package contain synthesized shapes under rotation and occlusion using the same template shapes as the Chui-Rangarajan data sets. The original data are saved as MAT files of MATLAB. Our C++ code does not process MAT files. Instead we provide a MATLAB tool, ConvertData.m, to convert MAT files to SYN files. SYN files are just text files with a simple structure.

In MATLABE, enter the directory containing data. The command "ConvertData" will convert all MAT files under the directory to SYN files, which are saved under the same directory.

Yefeng Zheng
Language and Media Processing Laboratory
University of Maryland, College Park

09/15/2005