This data set is synthesized by Dr. Haili Chui and Prof. Anand Rangarajan. Two shapes (fish and a Chinese characer) are used to generated data under deformation, noise, and outliers. The original data are saved as MAT files of MATLAB. Our C++ code does not process MAT files. Instead we provide a MATLAB tool, ConvertData.m, to convert MAT files to SYN files. SYN files are just Microsoft Windows text files with a simple structure.

In MATLABE, enter the directory containing data. The command "ConvertData" will convert all MAT files under the directory to SYN files, which are saved under the same directory.

Yefeng Zheng
Language and Media Processing Laboratory
University of Maryland, College Park

12/01/2004